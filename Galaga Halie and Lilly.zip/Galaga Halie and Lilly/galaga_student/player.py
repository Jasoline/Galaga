import os
import pygame as pg


class Player(pg.sprite.Sprite):
    def __init__(self, start_pos=(200, 700), speed=300):
        super(Player, self).__init__()
        self.image = pg.image.load(os.path.join('assets', 'Ship6.png')).convert_alpha()
        self.rect = self.image.get_rect(center=start_pos)  # Initialize position

        # Define movement bounds for the player (y-axis)
        self.yrange = (0, 768)
        self.speed = speed  # Movement speed in pixels per second

    def draw(self, screen):
        screen.blit(self.image, self.rect)

    def update(self, delta):
        pass

    def up(self, delta):
        new_top = self.rect.top - self.speed * delta
        if new_top >= self.yrange[0]:
            self.rect.top = new_top
        else:
            self.rect.top = self.yrange[0]

    def down(self, delta):
        new_bottom = self.rect.bottom + self.speed * delta
        if new_bottom <= self.yrange[1]:
            self.rect.bottom = new_bottom
        else:
            self.rect.bottom = self.yrange[1]
