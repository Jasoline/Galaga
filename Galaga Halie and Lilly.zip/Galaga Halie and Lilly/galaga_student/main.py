#!/usr/bin/env python3

import pygame as pg
import pygame.freetype
import os
from enemy import Enemy
from player import Player
from projectile import Projectile
from pygame.locals import *


def main():
    # Initialize pygame
    pg.init()

    # Set up the screen
    screen = pg.display.set_mode([1024, 768])

    # Create the player instance
    player = Player()

    # Create groups for enemies and projectiles
    enemies = pg.sprite.Group()
    projectiles = pg.sprite.Group()

    # Populate the enemy group with enemies in a grid pattern
    for i in range(500, 1000, 75):
        for j in range(100, 600, 50):
            enemy = Enemy((i, j))
            enemies.add(enemy)

    # Load and play background music
    try:
        background_music = os.path.join(os.path.dirname(__file__), "assets", "cpu-talk.mp3")
        pg.mixer.music.load(background_music)
        pg.mixer.music.play(-1)
    except Exception as e:
        print("Error loading music:", e)

    # Initialize font for rendering
    pg.freetype.init()
    font_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), "./assets", "PermanentMarker-Regular.ttf")
    font_size = 64
    font = pg.freetype.Font(font_path, font_size)
    FONTCOLOR = pg.Color(255, 0, 255)

    # Game loop variables
    running = True
    delta = 0
    shotDelta = 250  # Milliseconds between shots
    fps = 60
    clock = pg.time.Clock()
    score = 0
    game_won = False

    # Movement settings for enemy group
    yrange = (0, 768)  # boundaries for group movement
    speed_y = 100  # speed of the group
    direction = 1

    # Main game loop
    while running:
        for event in pg.event.get():
            if event.type == pg.QUIT:
                running = False
            if event.type == pg.USEREVENT + 1:
                score += 100

        # Check if all enemies are cleared
        if not enemies and not game_won:
            game_won = True
            screen.fill((0, 0, 0))
            font.render_to(screen, (400, 300), "You Win!", FONTCOLOR, None, size=74)
            pg.display.flip()
            pg.time.wait(2000)  # <-- we just learned this in class, so we thought it would be
            # neat to utilize it in our lab!!

        if not game_won:
            # Get keyboard input
            keys = pg.key.get_pressed()
            if keys[K_s]:
                player.down(delta)
            if keys[K_w]:
                player.up(delta)
            if keys[K_SPACE] and shotDelta >= 250:
                projectile = Projectile(player.rect, enemies)
                projectiles.add(projectile)
                shotDelta = 0

            # Check group boundaries and reverse direction if needed
            topmost = min(enemy.rect.top for enemy in enemies)
            bottommost = max(enemy.rect.bottom for enemy in enemies)

            if topmost <= yrange[0]:
                direction = 1
            elif bottommost >= yrange[1]:
                direction = -1

            # Move the entire enemy group
            for enemy in enemies:
                enemy.rect.y += speed_y * delta * direction

            # Update game objects
            player.update(delta)
            projectiles.update(delta)

            # Draw everything
            screen.fill((0, 0, 0))
            player.draw(screen)
            enemies.draw(screen)
            projectiles.draw(screen)
            font.render_to(screen, (10, 10), "Score: " + str(score), FONTCOLOR, None, size=64)

            # Flip the buffer to update the display
            pg.display.flip()

            # Manage frame rate and time
            delta = clock.tick(fps) / 1000.0
            shotDelta += delta * 1000

        else:
            # Display win screen with ESC to quit option
            screen.fill((0, 0, 0))
            font.render_to(screen, (400, 300), "You Win!", FONTCOLOR, None, size=74)
            font.render_to(screen, (380, 400), "Press ESC to quit", FONTCOLOR, None, size=48)
            pg.display.flip()

            keys = pg.key.get_pressed()
            if keys[K_ESCAPE]:
                running = False


# Run the game
if __name__ == "__main__":
    main()
    pg.quit()
