import os
import pygame as pg


class Projectile(pg.sprite.Sprite):
    def __init__(self, shipLocation, enemies, speed=1000):
        super(Projectile, self).__init__()
        self.image = pg.image.load(os.path.join('assets', 'shot.png')).convert_alpha()
        self.rect = self.image.get_rect(center=(shipLocation.centerx, shipLocation.centery))  # Centered on the ship
        self.enemies = enemies
        self.event = pg.USEREVENT + 1  # Custom event for scoring
        self.speed = speed  # Projectile speed

        # Load sounds with path handling
        self.fireSound = pg.mixer.Sound(os.path.join('assets', 'fire.wav'))
        self.explosionSound = pg.mixer.Sound(os.path.join('assets', 'explosion.wav'))

        # Play the firing sound
        self.fireSound.play()

    def draw(self, screen):
        screen.blit(self.image, self.rect)

    def update(self, delta):
        # Move the projectile to the right by speed * delta
        self.rect.x += self.speed * delta

        # Destroy the projectile if it goes off the screen
        if self.rect.x > 1024:
            self.kill()

        # Check for collisions with enemies
        collision = pg.sprite.spritecollideany(self, self.enemies)
        if collision:
            # Kill the enemy and play explosion sound
            collision.kill()
            self.explosionSound.play()

            # Post an event to increment score
            pg.event.post(pg.event.Event(self.event))

            # Remove the projectile after collision
            self.kill()
