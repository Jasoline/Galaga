import os
import pygame as pg
import random


class Enemy(pg.sprite.Sprite):
    def __init__(self, position=(0, 0)):
        super(Enemy, self).__init__()

        # Load the three possible enemy images
        self.images = [
            pg.image.load(os.path.join('assets', 'Ship1.png')).convert_alpha(),
            pg.image.load(os.path.join('assets', 'Ship2.png')).convert_alpha(),
            pg.image.load(os.path.join('assets', 'Ship3.png')).convert_alpha()
        ]

        # Randomly select one image for this instance
        self.image = random.choice(self.images)

        # Set the rectangle for positioning
        self.rect = self.image.get_rect(topleft=position)

    def draw(self, screen):
        screen.blit(self.image, self.rect)

    def update(self):
        pass
